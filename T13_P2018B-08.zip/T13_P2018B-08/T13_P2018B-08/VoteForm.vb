﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: Nomination
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class VoteForm

    'record structure for each nominee
    'Private Structure Nominee
    '    Public Name As String
    '    Public NumVotes As Integer

    'End Structure
    'Private Nominees() As Nominee
    Private numNominees As Integer

    ''Private frm As frmFreeStateGranniesSocialSavings
    Private Sub VoteForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '' frm = New frmFreeStateGranniesSocialSavings
    End Sub
    'takes the user back to the main form
    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click
        Me.Hide()
        frmFreeStateGranniesSocialSavings.Show()

    End Sub
    'allows the user to enter information for each nominee

    Private Sub btninput_Click(sender As Object, e As EventArgs) Handles btninput.Click
        'numNominees = CInt(txtNominee.Text)
        'ReDim Nominees(numNominees)

        'For n As Integer = 1 To numNominees
        '    Nominees(n).Name = InputBox("What is the name of the Nominee?")

        'Next n
        ''*************************************************************** RUBISH
        Dim indx As Integer
        Dim id As Decimal
        For i As Integer = 1 To frmFreeStateGranniesSocialSavings.Members.Length - 1
            If id = frmFreeStateGranniesSocialSavings.Members(i).IDnumber Then
                indx = i
            End If
        Next

        frmFreeStateGranniesSocialSavings.Members(indx).Votes.Nomination = InputBox("Enter Nomination")

    End Sub
    'subroutine that calculates the Charity that wins
    'Private Sub calcCharityWinner(ByRef idx As Integer)
    '    'Dim max As Integer
    '    'max = frmFreeStateGranniesSocialSavings.Members(1).Votes.Nvotes
    '    'idx = 1
    '    'For i As Integer = 1 To frmFreeStateGranniesSocialSavings.Members.Length - 1
    '    '    If max < frmFreeStateGranniesSocialSavings.Members(i).Votes.Nvotes Then
    '    '        max = frmFreeStateGranniesSocialSavings.Members(i).Votes.Nvotes
    '    '        idx = i
    '    '    End If
    '    'Next
    '    'txtWin.Text &= frmFreeStateGranniesSocialSavings.Members(idx).Votes.Nomination & vbCrLf
    '    'txtWin.Text &= CStr(frmFreeStateGranniesSocialSavings.Members(idx).Votes.Nvotes) & "Votes"


    'End Sub
    'enables user to enter the number of votes as well as the displaying of the nominees with their votes respectively

    Private Sub btnNominies_Click(sender As Object, e As EventArgs) Handles btnNominees.Click


        '    GOES THROUGH THE ARRAY TO DISPLAY ALL THE NOMINATIONS 
        For i As Integer = 1 To frmFreeStateGranniesSocialSavings.Members.Length - 1

            If frmFreeStateGranniesSocialSavings.Members(i).Votes.Nomination IsNot Nothing Then
                txtVote.Text &= frmFreeStateGranniesSocialSavings.Members(i).Votes.Nomination & vbCrLf

            End If
        Next

    End Sub
    Dim max As Integer

    Private Sub btnVote_Click(sender As Object, e As EventArgs) Handles btnVote.Click
        ''çhecks the nomination and adds the number of votes

        Dim v As String


        For j As Integer = 1 To frmFreeStateGranniesSocialSavings.Members.Length - 1
            v = InputBox("Enter name of Nominee being voted for")


            If v = frmFreeStateGranniesSocialSavings.Members(j).Votes.Nomination And v IsNot Nothing Then
                frmFreeStateGranniesSocialSavings.Members(j).Votes.Nvotes += 1
            End If
        Next

    End Sub

    Private Sub btnCWin_Click(sender As Object, e As EventArgs) Handles btnCWin.Click
        Dim max As Integer
        Dim idx As Integer
        max = frmFreeStateGranniesSocialSavings.Members(1).Votes.Nvotes
        idx = 1
        For i As Integer = 1 To frmFreeStateGranniesSocialSavings.Members.Length - 1
            If max < frmFreeStateGranniesSocialSavings.Members(i).Votes.Nvotes Then
                max = frmFreeStateGranniesSocialSavings.Members(i).Votes.Nvotes
                idx = i
            End If
        Next
        txtWin.Text &= frmFreeStateGranniesSocialSavings.Members(idx).Votes.Nomination & vbCrLf
        txtWin.Text &= CStr(frmFreeStateGranniesSocialSavings.Members(idx).Votes.Nvotes) & "Votes"
    End Sub
End Class