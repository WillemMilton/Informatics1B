﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: Nomination
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class VoteForm
    'record structure for each nominee
    Private Structure Nominee
        Public Name As String
        Public NumVotes As Integer

    End Structure
    Private Nominees() As Nominee
    Private numNominees As Integer

    'takes the user back to the main form
    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click
        Me.Hide()
        frmFreeStateGranniesSocialSavings.Show()

    End Sub
    'allows the user to enter information for each nominee

    Private Sub btninput_Click(sender As Object, e As EventArgs) Handles btninput.Click
        numNominees = CInt(txtNominee.Text)
        ReDim Nominees(numNominees)

        For n As Integer = 1 To numNominees
            Nominees(n).Name = InputBox("What is the name of the Nominee?")

        Next n

    End Sub
    'subroutine that calculates the Charity that wins
    Private Sub calcCharityWinner(ByRef idx As Integer)
        Dim max As Integer
        max = Nominees(1).NumVotes
        idx = 1
        For l As Integer = 1 To numNominees
            If max <= Nominees(l).NumVotes Then
                max = Nominees(l).NumVotes
                idx = l

            End If
        Next l
    End Sub
    'enables user to enter the number of votes as well as the displaying of the nominees with their votes respectively

    Private Sub btnVote_Click(sender As Object, e As EventArgs) Handles btnVote.Click

        For s As Integer = 1 To numNominees
            Nominees(s).NumVotes = CInt(InputBox("How many votes did " & Nominees(s).Name & " get?"))
        Next s
        For s As Integer = 1 To numNominees
            txtVote.Text &= "Name of the charity " & Nominees(s).Name & vbCrLf
            txtVote.Text &= "Number of votes for the charity is: " & Nominees(s).NumVotes & vbCrLf
        Next

    End Sub
    Dim max As Integer
    'calcCharitywinner(max)


End Class