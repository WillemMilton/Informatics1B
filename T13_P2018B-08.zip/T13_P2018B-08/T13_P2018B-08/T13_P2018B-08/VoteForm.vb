﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: Nomination
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class VoteForm

    ' record Structure for Each nominee
    Private Structure Nominee
        Public Name As String
        Public NumVotes As Integer

    End Structure
    Private Nominees() As Nominee
    Private numNominees As Integer
    '' Inherits frmFreeStateGranniesSocialSavings
    Private frm As frmFreeStateGranniesSocialSavings
    Private Sub VoteForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        frm = New frmFreeStateGranniesSocialSavings
    End Sub
    'takes the user back to the main form
    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click
        Me.Hide()
        frmFreeStateGranniesSocialSavings.Show()

    End Sub
    'allows the user to enter information for each nominee

    Private Sub btninput_Click(sender As Object, e As EventArgs) Handles btninput.Click
        numNominees = CInt(txtNominee.Text)
        ReDim Nominees(numNominees)

        For n As Integer = 1 To numNominees
            Nominees(n).Name = InputBox("What is the name of Project/Charity Nominee " & n & " ?")

        Next n

    End Sub

    Private Sub btnVote_Click(sender As Object, e As EventArgs) Handles btnVote.Click
        ''enters the number of votes per nominee
        For k As Integer = 1 To numNominees
            Nominees(k).NumVotes = CInt(InputBox("How many votes did nominee " & k & " get? "))
            txtVote.Text &= "Charity " & Nominees(k).Name & vbCrLf
            txtVote.Text &= "The charity " & Nominees(k).Name & " has " & Nominees(k).NumVotes & "Votes " & vbCrLf

        Next k

    End Sub
    'subroutine that calculates the Charity that wins
    Private Sub calcCharityWinner(ByRef idx As Integer)
        Dim max As Integer
        max = Nominees(1).NumVotes
        idx = 1
        For i As Integer = 1 To numNominees
            If max < Nominees(i).NumVotes Then
                max = Nominees(i).NumVotes
                idx = i
            End If
        Next i
        '   txtWin.Text = Nominees().Name

    End Sub


End Class