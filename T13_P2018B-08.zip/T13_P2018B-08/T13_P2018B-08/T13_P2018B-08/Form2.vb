﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: frmFreeStateGranniesSocialSavings
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class frmFreeStateGranniesSocialSavings
    Inherits System.Windows.Forms.Form
    Public Members() As Member
    Private NumOfMember, NumOfWeeks As Integer
    Private TotalInStokvel As Double
    Private Sub frmFreeStateGranniesSocialSavings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("Please Set The Interest rate before Entering any information")
    End Sub
    ' Subroutine for displaying the information on the grid
    Private Sub DisplayInfo(ByVal r As Integer, ByVal c As Integer, ByVal t As String)
        grdSocialSavings.Row = r
        grdSocialSavings.Col = c
        grdSocialSavings.Text = t
    End Sub

    Private Sub btnMembersRecords_Click(sender As Object, e As EventArgs) Handles btnMembersRecords.Click
        ' get the number of members 
        NumOfMember = CInt(InputBox("How many member's you want to add?"))
        NumOfWeeks = CInt(InputBox("For how many weeks do you want to record their Information?"))
        ReDim Members(NumOfMember)


        ' Set Cols ANd Rows 
        grdSocialSavings.Rows = NumOfMember + 1
        grdSocialSavings.Cols = NumOfWeeks + 3

        ' Instanstiate any objects of member class
        For x As Integer = 1 To NumOfMember
            Members(x) = New Member(NumOfMember, NumOfWeeks)
            Members(x).Addresses(x) = New Address
            '  Members(x).Votes = New Vote
            Members(x).Loans = New Loan

            'ReDim Members(x).WeeklyContribution(NumOfWeeks)

        Next x
        ' Loop for storing the info of all member's 
        For x As Integer = 1 To NumOfMember
            Members(x).Surname = InputBox("What's the Surname of Member " & CStr(x) & "?")
            Members(x).Name = InputBox("What's the Name of Member " & CStr(x) & "?")
            Members(x).Age = CInt(InputBox("How Old is " & Members(x).Name & " " & Members(x).Surname & "?"))
            Members(x).BirthDay = InputBox("Please Enter " & Members(x).Name & " " & Members(x).Surname & "Birthday in the Format YYYY/MM/DD ")
            Members(x).IDnumber = CInt(InputBox("Please Enter " & Members(x).Name & "'s  ID Number"))
            Members(x).Addresses(x).Street = InputBox("Please provide the Street Name")
            Members(x).Addresses(x).CityTown = InputBox("Please provide the City Or Town")
            Members(x).Addresses(x).PostalCode = CInt(InputBox("Provide The Postal Code"))
            Members(x).Addresses(x).Country = InputBox("Provide The Country")

        Next x
        For n As Integer = 1 To NumOfMember
            DisplayInfo(n, 0, "[ " & Members(n).IDnumber & " ]" & Members(n).Name & " " & Members(n).Surname)
        Next n
        For y As Integer = 1 To NumOfWeeks
            DisplayInfo(0, y, "Week " & CStr(y))
        Next y
        grdSocialSavings.set_ColWidth(0, 150)
        grdSocialSavings.set_ColWidth(NumOfWeeks + 1, 150)
        DisplayInfo(0, NumOfWeeks + 1, "Owes How Much")
        DisplayInfo(0, 0, "[ID Number] Name & Surname")
    End Sub

    Private Sub btnSetInterestRate_Click(sender As Object, e As EventArgs) Handles btnSetInterestRate.Click
        Dim Interest As Double
        Interest = CDbl(InputBox("Set the interest in percentage"))
        For x As Integer = 1 To NumOfMember
            Members(x).Loans.InterestRate = Interest / 100

        Next x
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        MessageBox.Show("Are you sure you want to Exit?", "Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation)
        Me.Close()
    End Sub

    Private Sub btnWeeklyAmount_Click(sender As Object, e As EventArgs) Handles btnWeeklyAmount.Click
        'recording weekly contribution payments
        Dim numContributing, ind As Integer
        Dim Id As Decimal

        Dim total As Double
        total = 0
        'For w As Integer = 1 To NumOfWeeks
        '    numContributing = CInt(InputBox("How many people are present to make contributions in week " & w & " ?"))
        '    For x As Integer = 1 To numContributing
        '        Id = CDec(InputBox("What is the ID number?"))
        '        'finding the index of the member contributing
        '        For p As Integer = 1 To Members.Length - 1
        '            If Id = Members(x).IDnumber Then
        '                ind = p
        '                Members(x).WeeklyContribution(w) = CDbl(InputBox("How much is the contribution of " & Id & "?"))
        '            End If

        '            'Members(ind).WeeklyContribution(w) = CDbl(InputBox("How much is the contribution of " & Id & "?"))
        '        Next p

        '        DisplayInfo(x, w, CStr(Members(x).WeeklyContribution(w)))
        '        total += Members(x).WeeklyContribution(w)
        '        'TotalInStokvel += total
        '    Next x
        '    Next w
        'txtTotalMoney.Text = CStr(total)





        '************************************************************

        For w As Integer = 1 To NumOfWeeks
            For x As Integer = 1 To NumOfMember
                Members(x).WeeklyContribution(w) = CDbl(InputBox("how much is the contribution of  member" & x & " in week " & w & " ?"))
                DisplayInfo(x, w, CStr(Members(x).WeeklyContribution(w)))
                total += Members(x).WeeklyContribution(w)
                txtTotalMoney.Text = CStr(total)
                TotalInStokvel = total
            Next x
        Next w



    End Sub

    Private Sub btnBorrowMoney_Click(sender As Object, e As EventArgs) Handles btnBorrowMoney.Click
        Dim Id As Decimal
        Dim i, index As Integer
        Dim Amount As Double
        Dim IntrestRT As Double

        'get the id number of member borrowing money from chest and get the
        'indexof Member to do calculations for the loans 
        Id = CDec(InputBox("Please Enter ID of Member..."))
        For i = 1 To Members.Length - 1
            If Id = Members(i).IDnumber Then
                index = i
            End If
        Next
        'helps take in the amount being borrowed
        Dim AmBorrw As Double
        AmBorrw = CDbl(InputBox("Please Enter Amount member:" + Members(index).Name + " " + CStr(Members(index).IDnumber) _
                                + "Wants to borrrow"))

        intrestRT = CInt(InputBox("What is the Interest rate In % "))   ''++++++++++++++++++++++++++
        Members(index).Loans.InterestRate = intrestRT / 100     ''+++++++++++++++++++++++++++++++++

        'checks if there is enough cash in the chest
        If AmBorrw > TotalInStokvel Then
            MsgBox("Insufficient Funds In Chest")
        ElseIf AmBorrw <= 0 Then
            'incase negative amounts are entered
            MsgBox("Invalid loan amount")
        ElseIf AmBorrw < TotalInStokvel Then
            If Members(index).Loans.StillOwing = 0 Then
                'calculates the amount he member now owes

                Members(index).Loans.AmountBorrowing = AmBorrw
                Amount = Members(index).Loans.Borrowmoney(TotalInStokvel, AmBorrw)

                MsgBox("LOAN GRANTED!" & vbCrLf & "Member " + Members(index).Name + " " + CStr(Members(index).IDnumber) + " Now Owes: " + "R" + CStr(Amount))
            ElseIf Members(index).Loans.StillOwing > 0 Then
                MsgBox("LOAN NOT GRANTED! Member is still owing the chest")
            End If

            'updates the amount of money that is in the community chest according to the amount borrowed
            txtTotalMoney.Text = CStr(TotalInStokvel)
            DisplayInfo(index, NumOfWeeks + 1, CStr(Members(index).Loans.StillOwing))
        End If

    End Sub

    Private Sub btnPayMoney_Click(sender As Object, e As EventArgs) Handles btnPayMoney.Click
        'takes in money that the member wants to pay back

        Dim Id As Decimal
        Dim i, index As Integer

        'get the id number of member borrowing money from chest and get the
        'indexof Member to do calculations for the loans 
        Id = CDec(InputBox("Please Enter ID of Member..."))
        For i = 1 To Members.Length - 1
            If Id = Members(i).IDnumber Then
                index = i
            End If
        Next

        MsgBox(" Member: " + Members(index).Name + CStr(Members(index).IDnumber) + " Owes: " +
               CStr(Members(index).Loans.StillOwing))

        'enter amount of money the member wants to pay back 
        Members(index).Loans.Payment = CDbl(InputBox("Please Enter the amount " + Members(index).Name +
            "wants to pay.."))
        If Members(index).Loans.Payment < 0 Then
            MsgBox("Invalid payment Amount")
        Else
            Members(index).Loans.Pay(TotalInStokvel, Members(index).Loans.Payment)
        End If

        MsgBox("Member " + Members(index).Name + " " + CStr(Members(index).IDnumber) + " Now Owes: " + CStr(Members(index).Loans.StillOwing))
        'updates the amount of money in the community chest according to the money the member paid
        txtTotalMoney.Text = CStr(TotalInStokvel)


    End Sub
    'hides the form2 then shows the vote form
    Private Sub btnVote_Click(sender As Object, e As EventArgs) Handles btnVote.Click
        Me.Hide()
        VoteForm.Show()

    End Sub
    ' Change Interest rate
    Private Sub btnChangeInterest_Click(sender As Object, e As EventArgs) Handles btnChangeInterest.Click

    End Sub
End Class