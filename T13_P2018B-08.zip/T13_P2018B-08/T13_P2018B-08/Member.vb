﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: Member
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class Member
    Private _Surname As String
    Private _Name As String
    Private _Age As Integer
    Private _BirthDay As String
    Private _Addresses() As Address
    Private _IDnumber As Decimal
    Private _Votes As Vote
    Private _Loans As Loan 'we cant have loans as an array
    Private _InterestRate As Double
    Private _WeeklyContribution() As Double

    ' Property method for Surname 
    Public Property Surname As String
        Get
            Return _Surname
        End Get
        Set(value As String)
            _Surname = value
        End Set
    End Property
    ' Property method for name 
    Public Property Name As String
        Get
            Return _Name
        End Get
        Set(value As String)
            _Name = value
        End Set
    End Property
    ' Property method for age 
    Public Property Age As Integer
        Get
            Return _Age
        End Get
        Set(value As Integer)
            _Age = value
        End Set
    End Property
    ' Property method for Birthday 
    Public Property BirthDay As String
        Get
            Return _BirthDay
        End Get
        Set(value As String)
            _BirthDay = value
        End Set
    End Property
    ' Property method for Address
    Public Property Addresses(ByVal x As Integer) As Address
        Get
            Return _Addresses(x)
        End Get
        Set(value As Address)
            _Addresses(x) = value
        End Set
    End Property
    'Property method for ID Numbers
    Public Property IDnumber As Decimal
        Get
            Return _IDnumber
        End Get
        Set(Value As Decimal)
            _IDnumber = Value
        End Set
    End Property
    ' Property method for Votes 
    Public Property Votes() As Vote
        Get
            Return _Votes
        End Get
        Set(value As Vote)
            _Votes = value
        End Set
    End Property
    ' Property method for loans
    Public Property Loans() As Loan
        Get
            Return _Loans
        End Get
        Set(value As Loan)
            _Loans = value
        End Set
    End Property
    ' Property method for an interest rate 
    Public Property InterestRate As Double
        Get
            Return _InterestRate
        End Get
        Set(value As Double)
            _InterestRate = value
        End Set
    End Property
    ' Constructor 
    Public Sub New(ByVal x As Integer, ByVal nw As Integer)
        '' ReDim _Votes(x)
        ReDim _Addresses(x)
        ReDim _WeeklyContribution(nw)
    End Sub
    'Property Method for a weekly contribution 
    Public Property WeeklyContribution(ByVal i As Integer) As Double
        Get
            Return _WeeklyContribution(i)
        End Get
        Set(value As Double)
            _WeeklyContribution(i) = value
        End Set
    End Property
    ' Calculating the interest rate 
    Public Function Interest() As Double

    End Function
    ' Vakidation for ID Number's 
    Public Function IDValidation(ByVal ID As Integer) As Integer
        If ID > 13 Then
            ID = 0
        Else
            ID = ID
        End If
        Return ID
    End Function
End Class
