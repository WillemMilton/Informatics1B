﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: frmFreeStateGranniesSocialSavings
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class frmFreeStateGranniesSocialSavings
    Inherits System.Windows.Forms.Form
    Private Members() As Member
    Private NumOfMember, NumOfWeeks As Integer
    Private TotalInStokvel, Total As Double
    Private Sub frmFreeStateGranniesSocialSavings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("Please Set The Interest rate before Entering any information")
    End Sub
    ' Subroutine for displaying the information on the grid
    Private Sub DisplayInfo(ByVal r As Integer, ByVal c As Integer, ByVal t As String)
        grdSocialSavings.Row = r
        grdSocialSavings.Col = c
        grdSocialSavings.Text = t
    End Sub

    Private Sub btnMembersRecords_Click(sender As Object, e As EventArgs) Handles btnMembersRecords.Click
        ' get the number of members 
        NumOfMember = CInt(InputBox("How many member's you want to add?"))
        NumOfWeeks = CInt(InputBox("For how many weeks do you want to record their Information?"))
        ReDim Members(NumOfMember)
        ' Set Cols ANd Rows 
        grdSocialSavings.Rows = NumOfMember + 1
        grdSocialSavings.Cols = NumOfWeeks + 3

        ' Instanstiate any objects of member class
        For x As Integer = 1 To NumOfMember
            Members(x) = New Member(NumOfMember)
            Members(x).Addresses(x) = New Address
            Members(x).Votes(x) = New Vote
            Members(x).Loans(x) = New Loan
        Next x
        ' Loop for storing the info of all member's 
        For x As Integer = 1 To NumOfMember
            Members(x).Surname = InputBox("What's the Surname of Member " & CStr(x) & "?")
            Members(x).Name = InputBox("What's the Name of Member " & CStr(x) & "?")
            Members(x).Age = CInt(InputBox("How Old is " & Members(x).Name & " " & Members(x).Surname & "?"))
            Members(x).BirthDay = InputBox("Please Enter " & Members(x).Name & " " & Members(x).Surname & "Birthday in the Format YYYY/MM/DD ")
            Members(x).IDnumber = CDec(InputBox("Please Enter " & Members(x).Name & "'s  ID Number"))
            Members(x).Addresses(x).Street = InputBox("Please provide the Street Name")
            Members(x).Addresses(x).CityTown = InputBox("Please provide the City Or Town")
            Members(x).Addresses(x).PostalCode = CInt(InputBox("Provide The Postal Code"))
            Members(x).Addresses(x).Country = InputBox("Provide The Country")

        Next x
        For n As Integer = 1 To NumOfMember
            DisplayInfo(n, 0, "[ " & Members(n).IDnumber & " ]" & Members(n).Name & " " & Members(n).Surname)
        Next n
        For y As Integer = 1 To NumOfWeeks
            DisplayInfo(0, y, "Week " & CStr(y))
        Next y
        grdSocialSavings.set_ColWidth(0, 150)
        grdSocialSavings.set_ColWidth(NumOfWeeks + 1, 150)
        DisplayInfo(0, NumOfWeeks + 1, "Owes Money(Yes/No)")
        DisplayInfo(0, 0, "[ID Number] Name & Surname")
    End Sub

    Private Sub btnSetInterestRate_Click(sender As Object, e As EventArgs) Handles btnSetInterestRate.Click
        Dim Interest As Double
        Interest = CDbl(InputBox("Set the interest in percentage"))
        For x As Integer = 1 To NumOfMember
            Members(x).Loans(x).InterestRate = CDbl(Interest)
        Next x
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        MessageBox.Show("Are you sure you want to Exit?", "Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation)
        Me.Close()
    End Sub

    Private Sub btnWeeklyAmount_Click(sender As Object, e As EventArgs) Handles btnWeeklyAmount.Click
        'recording weekly contribution payments
        Dim numContributing As Integer
        Dim Id As Decimal
        Dim total As Double
        total = 0
        For w As Integer = 1 To NumOfWeeks
            numContributing = CInt(InputBox("How many people are present to make contributions in week " & w & " ?"))
            For x As Integer = 1 To numContributing
                Id = CDec(InputBox("What is the ID number?"))

                'Members(y) = New Member(NumOfWeeks)
                If Id = Members(x).IDnumber Then
                    Members(x).WeeklyContribution(w) = CDbl(InputBox("How much is the contribution of " & Id & "?"))
                    total += Members(x).WeeklyContribution(w)
                Else
                        MsgBox("Please provide the correct ID")
                    End If
                DisplayInfo(x, w, "R" & CStr(Members(x).WeeklyContribution(w)))

            Next x

        Next w
        txtTotalMoney.Text = "R" & total

    End Sub

    Private Sub btnPayMoney_Click(sender As Object, e As EventArgs) Handles btnPayMoney.Click
        Dim Owes As Double
        For x As Integer = 1 To NumOfMember
            Dim borrowed As Integer = CInt(InputBox(Members(x).Name & " " & Members(x).Surname & " Owes " & "R" & Members(x).Loans(x).AmountBorrowed &
                                                  vbCrLf & " Is this member paying? Select 1" & vbCrLf & " If not Please Select 2"))
            Select Case borrowed
                Case 1
                    Dim Pay As Double = CDbl(InputBox("Please enter the amount the member is paying"))
                    Owes = Members(x).Loans(x).MoneyPayed(Pay)
                    If Owes = 0 Then
                        MsgBox(Members(x).Name & " " & Members(x).Surname & " does not owe money")
                    Else
                        MsgBox(Members(x).Name & " " & Members(x).Surname & "Owes R" & CStr(Owes))
                    End If
                Case 2
                    MsgBox("Okay")
            End Select

        Next x
    End Sub

    Private Sub btnBorrowMoney_Click(sender As Object, e As EventArgs) Handles btnBorrowMoney.Click
        Dim ID As Decimal
        Dim Amount, Borrowed As Double
        Dim Memb, Count As Integer
        Count = CInt(InputBox("How many members are borrowing money"))
        For x As Integer = 1 To Count
            Memb = CInt(InputBox("Which member is borrowing money? Member 1,2,3,...ect."))
            ID = CDec(InputBox("What's the ID number for the member who's borrowing money? "))
            If ID = Members(Memb).IDnumber Then
                Amount = CDbl(InputBox("How much " & Members(Memb).Name & " " & Members(Memb).Surname & " Is borrowing?"))
                Borrowed = Members(Memb).Loans(Memb).Borrowmoney(Total, Amount)
                If Borrowed = Members(Memb).Loans(Memb).AmountBorrowed Then
                    Borrowed = Members(Memb).Loans(Memb).AmountBorrowed
                    DisplayInfo(Memb, NumOfWeeks + 1, "Yes")
                Else
                    MsgBox(Members(Memb).Name & " " & Members(Memb).Surname & " Still owes money ")
                End If
            Else
                MsgBox("The ID Number does not match")
            End If

        Next x

    End Sub
    ' Change Interest rate
    Private Sub btnChangeInterest_Click(sender As Object, e As EventArgs) Handles btnChangeInterest.Click
        Dim ResetInt As Double
        ResetInt = CDbl(InputBox("Insert the new interest rate"))
        For x As Integer = 1 To NumOfMember
            Members(x).Loans(x).InterestRate = ResetInt
        Next x

    End Sub
End Class