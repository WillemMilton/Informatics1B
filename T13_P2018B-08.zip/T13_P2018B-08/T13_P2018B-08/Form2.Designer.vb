﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFreeStateGranniesSocialSavings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnChangeInterest = New System.Windows.Forms.Button()
        Me.btnMembersRecords = New System.Windows.Forms.Button()
        Me.btnRemoveMember = New System.Windows.Forms.Button()
        Me.btnBorrowMoney = New System.Windows.Forms.Button()
        Me.grdSocialSavings = New UJGrid.UJGrid()
        Me.btnPayMoney = New System.Windows.Forms.Button()
        Me.btnWeeklyAmount = New System.Windows.Forms.Button()
        Me.btnInterestRepayments = New System.Windows.Forms.Button()
        Me.btnProfitSpending = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnSetInterestRate = New System.Windows.Forms.Button()
        Me.txtTotalMoney = New System.Windows.Forms.TextBox()
        Me.lblTotalMoney = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnChangeInterest
        '
        Me.btnChangeInterest.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnChangeInterest.Location = New System.Drawing.Point(12, 66)
        Me.btnChangeInterest.Name = "btnChangeInterest"
        Me.btnChangeInterest.Size = New System.Drawing.Size(161, 50)
        Me.btnChangeInterest.TabIndex = 0
        Me.btnChangeInterest.Text = "Change Interest Rate"
        Me.btnChangeInterest.UseVisualStyleBackColor = False
        '
        'btnMembersRecords
        '
        Me.btnMembersRecords.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnMembersRecords.Location = New System.Drawing.Point(179, 12)
        Me.btnMembersRecords.Name = "btnMembersRecords"
        Me.btnMembersRecords.Size = New System.Drawing.Size(143, 51)
        Me.btnMembersRecords.TabIndex = 1
        Me.btnMembersRecords.Text = "Add Member"
        Me.btnMembersRecords.UseVisualStyleBackColor = False
        '
        'btnRemoveMember
        '
        Me.btnRemoveMember.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRemoveMember.Location = New System.Drawing.Point(328, 12)
        Me.btnRemoveMember.Name = "btnRemoveMember"
        Me.btnRemoveMember.Size = New System.Drawing.Size(155, 51)
        Me.btnRemoveMember.TabIndex = 2
        Me.btnRemoveMember.Text = "Remove Member"
        Me.btnRemoveMember.UseVisualStyleBackColor = False
        '
        'btnBorrowMoney
        '
        Me.btnBorrowMoney.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnBorrowMoney.Location = New System.Drawing.Point(12, 288)
        Me.btnBorrowMoney.Name = "btnBorrowMoney"
        Me.btnBorrowMoney.Size = New System.Drawing.Size(161, 50)
        Me.btnBorrowMoney.TabIndex = 4
        Me.btnBorrowMoney.Text = "Borrow Money"
        Me.btnBorrowMoney.UseVisualStyleBackColor = False
        '
        'grdSocialSavings
        '
        Me.grdSocialSavings.FixedCols = 1
        Me.grdSocialSavings.FixedRows = 1
        Me.grdSocialSavings.Location = New System.Drawing.Point(176, 69)
        Me.grdSocialSavings.Name = "grdSocialSavings"
        Me.grdSocialSavings.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdSocialSavings.Size = New System.Drawing.Size(599, 380)
        Me.grdSocialSavings.TabIndex = 5
        '
        'btnPayMoney
        '
        Me.btnPayMoney.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnPayMoney.Location = New System.Drawing.Point(8, 344)
        Me.btnPayMoney.Name = "btnPayMoney"
        Me.btnPayMoney.Size = New System.Drawing.Size(165, 51)
        Me.btnPayMoney.TabIndex = 6
        Me.btnPayMoney.Text = "Pay Money Borrowed"
        Me.btnPayMoney.UseVisualStyleBackColor = False
        '
        'btnWeeklyAmount
        '
        Me.btnWeeklyAmount.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnWeeklyAmount.Location = New System.Drawing.Point(12, 122)
        Me.btnWeeklyAmount.Name = "btnWeeklyAmount"
        Me.btnWeeklyAmount.Size = New System.Drawing.Size(161, 51)
        Me.btnWeeklyAmount.TabIndex = 7
        Me.btnWeeklyAmount.Text = "Pay The Weekly Amount"
        Me.btnWeeklyAmount.UseVisualStyleBackColor = False
        '
        'btnInterestRepayments
        '
        Me.btnInterestRepayments.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnInterestRepayments.Location = New System.Drawing.Point(12, 179)
        Me.btnInterestRepayments.Name = "btnInterestRepayments"
        Me.btnInterestRepayments.Size = New System.Drawing.Size(161, 48)
        Me.btnInterestRepayments.TabIndex = 8
        Me.btnInterestRepayments.Text = "Interest Repayments"
        Me.btnInterestRepayments.UseVisualStyleBackColor = False
        '
        'btnProfitSpending
        '
        Me.btnProfitSpending.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnProfitSpending.Location = New System.Drawing.Point(12, 233)
        Me.btnProfitSpending.Name = "btnProfitSpending"
        Me.btnProfitSpending.Size = New System.Drawing.Size(161, 49)
        Me.btnProfitSpending.TabIndex = 9
        Me.btnProfitSpending.Text = "Profit Spending "
        Me.btnProfitSpending.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(5, 401)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(165, 48)
        Me.btnClose.TabIndex = 10
        Me.btnClose.Text = "Exit"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSetInterestRate
        '
        Me.btnSetInterestRate.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSetInterestRate.Location = New System.Drawing.Point(12, 12)
        Me.btnSetInterestRate.Name = "btnSetInterestRate"
        Me.btnSetInterestRate.Size = New System.Drawing.Size(161, 48)
        Me.btnSetInterestRate.TabIndex = 11
        Me.btnSetInterestRate.Text = "Set The Interest Rate"
        Me.btnSetInterestRate.UseVisualStyleBackColor = False
        '
        'txtTotalMoney
        '
        Me.txtTotalMoney.Location = New System.Drawing.Point(489, 43)
        Me.txtTotalMoney.Name = "txtTotalMoney"
        Me.txtTotalMoney.Size = New System.Drawing.Size(286, 20)
        Me.txtTotalMoney.TabIndex = 12
        '
        'lblTotalMoney
        '
        Me.lblTotalMoney.AutoSize = True
        Me.lblTotalMoney.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalMoney.Location = New System.Drawing.Point(515, 12)
        Me.lblTotalMoney.Name = "lblTotalMoney"
        Me.lblTotalMoney.Size = New System.Drawing.Size(220, 13)
        Me.lblTotalMoney.TabIndex = 13
        Me.lblTotalMoney.Text = "Total Money In The Commumity Chest"
        '
        'frmFreeStateGranniesSocialSavings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(787, 459)
        Me.Controls.Add(Me.lblTotalMoney)
        Me.Controls.Add(Me.txtTotalMoney)
        Me.Controls.Add(Me.btnSetInterestRate)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnProfitSpending)
        Me.Controls.Add(Me.btnInterestRepayments)
        Me.Controls.Add(Me.btnWeeklyAmount)
        Me.Controls.Add(Me.btnPayMoney)
        Me.Controls.Add(Me.grdSocialSavings)
        Me.Controls.Add(Me.btnBorrowMoney)
        Me.Controls.Add(Me.btnRemoveMember)
        Me.Controls.Add(Me.btnMembersRecords)
        Me.Controls.Add(Me.btnChangeInterest)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmFreeStateGranniesSocialSavings"
        Me.Text = "The Free State Grannies Social Savings"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnChangeInterest As Button
    Friend WithEvents btnMembersRecords As Button
    Friend WithEvents btnRemoveMember As Button
    Friend WithEvents btnBorrowMoney As Button
    Friend WithEvents grdSocialSavings As UJGrid.UJGrid
    Friend WithEvents btnPayMoney As Button
    Friend WithEvents btnWeeklyAmount As Button
    Friend WithEvents btnInterestRepayments As Button
    Friend WithEvents btnProfitSpending As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents btnSetInterestRate As Button
    Friend WithEvents txtTotalMoney As TextBox
    Friend WithEvents lblTotalMoney As Label
End Class
