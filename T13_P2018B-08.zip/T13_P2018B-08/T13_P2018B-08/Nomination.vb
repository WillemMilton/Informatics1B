﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: Nomination
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class Nomination
    Private _ID As Decimal
    Private _CherityProgram As String
    ' Property method for ID
    Public Property ID As Decimal
        Get
            Return _ID
        End Get
        Set(value As Decimal)
            _ID = value
        End Set
    End Property
    ' Property method for Cherity Program 
    Public Property CherityProgram As String
        Get
            Return _CherityProgram
        End Get
        Set(value As String)
            _CherityProgram = value
        End Set
    End Property
    ' 
End Class
