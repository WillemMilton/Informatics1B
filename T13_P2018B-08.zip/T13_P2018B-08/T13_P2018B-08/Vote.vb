﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: Vote
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class Vote

    ''instance variables
    Private _Nomination As String
    Private _Nvotes As Integer

    ''property method for Nomination
    Public Property Nomination() As String
        Get
            Return _Nomination
        End Get
        Set(value As String)
            _Nomination = value
        End Set
    End Property
    ''property for Nvotes
    Public Property Nvotes() As Integer
        Get
            Return _Nvotes
        End Get
        Set(value As Integer)
            _Nvotes = value
        End Set
    End Property



End Class
