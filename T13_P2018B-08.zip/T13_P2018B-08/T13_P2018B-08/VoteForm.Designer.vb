﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VoteForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btninput = New System.Windows.Forms.Button()
        Me.txtWin = New System.Windows.Forms.TextBox()
        Me.txtVote = New System.Windows.Forms.TextBox()
        Me.btnNominees = New System.Windows.Forms.Button()
        Me.btnEnd = New System.Windows.Forms.Button()
        Me.btnVote = New System.Windows.Forms.Button()
        Me.btnCWin = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btninput
        '
        Me.btninput.Location = New System.Drawing.Point(15, 21)
        Me.btninput.Name = "btninput"
        Me.btninput.Size = New System.Drawing.Size(222, 23)
        Me.btninput.TabIndex = 0
        Me.btninput.Text = "Nominate"
        Me.btninput.UseVisualStyleBackColor = True
        '
        'txtWin
        '
        Me.txtWin.Location = New System.Drawing.Point(137, 299)
        Me.txtWin.Name = "txtWin"
        Me.txtWin.Size = New System.Drawing.Size(171, 20)
        Me.txtWin.TabIndex = 1
        '
        'txtVote
        '
        Me.txtVote.Location = New System.Drawing.Point(-2, 94)
        Me.txtVote.Multiline = True
        Me.txtVote.Name = "txtVote"
        Me.txtVote.Size = New System.Drawing.Size(288, 152)
        Me.txtVote.TabIndex = 2
        '
        'btnNominees
        '
        Me.btnNominees.Location = New System.Drawing.Point(15, 62)
        Me.btnNominees.Name = "btnNominees"
        Me.btnNominees.Size = New System.Drawing.Size(222, 23)
        Me.btnNominees.TabIndex = 6
        Me.btnNominees.Text = "Show Nominees"
        Me.btnNominees.UseVisualStyleBackColor = True
        '
        'btnEnd
        '
        Me.btnEnd.Location = New System.Drawing.Point(15, 343)
        Me.btnEnd.Name = "btnEnd"
        Me.btnEnd.Size = New System.Drawing.Size(222, 36)
        Me.btnEnd.TabIndex = 7
        Me.btnEnd.Text = "End Voting Process"
        Me.btnEnd.UseVisualStyleBackColor = True
        '
        'btnVote
        '
        Me.btnVote.Location = New System.Drawing.Point(15, 252)
        Me.btnVote.Name = "btnVote"
        Me.btnVote.Size = New System.Drawing.Size(239, 23)
        Me.btnVote.TabIndex = 8
        Me.btnVote.Text = "Cast Vote"
        Me.btnVote.UseVisualStyleBackColor = True
        '
        'btnCWin
        '
        Me.btnCWin.Location = New System.Drawing.Point(15, 299)
        Me.btnCWin.Name = "btnCWin"
        Me.btnCWin.Size = New System.Drawing.Size(116, 23)
        Me.btnCWin.TabIndex = 9
        Me.btnCWin.Text = "Chest Winner"
        Me.btnCWin.UseVisualStyleBackColor = True
        '
        'VoteForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(339, 391)
        Me.Controls.Add(Me.btnCWin)
        Me.Controls.Add(Me.btnVote)
        Me.Controls.Add(Me.btnEnd)
        Me.Controls.Add(Me.btnNominees)
        Me.Controls.Add(Me.txtVote)
        Me.Controls.Add(Me.txtWin)
        Me.Controls.Add(Me.btninput)
        Me.Name = "VoteForm"
        Me.Text = "frmVote"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btninput As Button
    Friend WithEvents txtWin As TextBox
    Friend WithEvents txtVote As TextBox
    Friend WithEvents btnNominees As Button
    Friend WithEvents btnEnd As Button
    Friend WithEvents btnVote As Button
    Friend WithEvents btnCWin As Button
End Class
