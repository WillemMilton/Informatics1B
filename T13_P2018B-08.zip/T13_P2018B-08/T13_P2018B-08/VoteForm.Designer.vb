﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VoteForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btninput = New System.Windows.Forms.Button()
        Me.txtprofit = New System.Windows.Forms.TextBox()
        Me.txtVote = New System.Windows.Forms.TextBox()
        Me.lblNominee = New System.Windows.Forms.Label()
        Me.txtNominee = New System.Windows.Forms.TextBox()
        Me.lblProfit = New System.Windows.Forms.Label()
        Me.btnVote = New System.Windows.Forms.Button()
        Me.btnEnd = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btninput
        '
        Me.btninput.Location = New System.Drawing.Point(32, 45)
        Me.btninput.Name = "btninput"
        Me.btninput.Size = New System.Drawing.Size(222, 23)
        Me.btninput.TabIndex = 0
        Me.btninput.Text = "Input"
        Me.btninput.UseVisualStyleBackColor = True
        '
        'txtprofit
        '
        Me.txtprofit.Location = New System.Drawing.Point(132, 287)
        Me.txtprofit.Name = "txtprofit"
        Me.txtprofit.Size = New System.Drawing.Size(171, 20)
        Me.txtprofit.TabIndex = 1
        '
        'txtVote
        '
        Me.txtVote.Location = New System.Drawing.Point(15, 118)
        Me.txtVote.Multiline = True
        Me.txtVote.Name = "txtVote"
        Me.txtVote.Size = New System.Drawing.Size(288, 152)
        Me.txtVote.TabIndex = 2
        '
        'lblNominee
        '
        Me.lblNominee.AutoSize = True
        Me.lblNominee.Location = New System.Drawing.Point(29, 22)
        Me.lblNominee.Name = "lblNominee"
        Me.lblNominee.Size = New System.Drawing.Size(104, 13)
        Me.lblNominee.TabIndex = 3
        Me.lblNominee.Text = "Number of nominees"
        '
        'txtNominee
        '
        Me.txtNominee.Location = New System.Drawing.Point(182, 19)
        Me.txtNominee.Name = "txtNominee"
        Me.txtNominee.Size = New System.Drawing.Size(100, 20)
        Me.txtNominee.TabIndex = 4
        '
        'lblProfit
        '
        Me.lblProfit.AutoSize = True
        Me.lblProfit.Location = New System.Drawing.Point(12, 294)
        Me.lblProfit.Name = "lblProfit"
        Me.lblProfit.Size = New System.Drawing.Size(61, 13)
        Me.lblProfit.TabIndex = 5
        Me.lblProfit.Text = "Chest Profit"
        '
        'btnVote
        '
        Me.btnVote.Location = New System.Drawing.Point(32, 86)
        Me.btnVote.Name = "btnVote"
        Me.btnVote.Size = New System.Drawing.Size(222, 23)
        Me.btnVote.TabIndex = 6
        Me.btnVote.Text = "vote"
        Me.btnVote.UseVisualStyleBackColor = True
        '
        'btnEnd
        '
        Me.btnEnd.Location = New System.Drawing.Point(32, 313)
        Me.btnEnd.Name = "btnEnd"
        Me.btnEnd.Size = New System.Drawing.Size(222, 36)
        Me.btnEnd.TabIndex = 7
        Me.btnEnd.Text = "End Voting Process"
        Me.btnEnd.UseVisualStyleBackColor = True
        '
        'VoteForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(339, 361)
        Me.Controls.Add(Me.btnEnd)
        Me.Controls.Add(Me.btnVote)
        Me.Controls.Add(Me.lblProfit)
        Me.Controls.Add(Me.txtNominee)
        Me.Controls.Add(Me.lblNominee)
        Me.Controls.Add(Me.txtVote)
        Me.Controls.Add(Me.txtprofit)
        Me.Controls.Add(Me.btninput)
        Me.Name = "VoteForm"
        Me.Text = "frmVote"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btninput As Button
    Friend WithEvents txtprofit As TextBox
    Friend WithEvents txtVote As TextBox
    Friend WithEvents lblNominee As Label
    Friend WithEvents txtNominee As TextBox
    Friend WithEvents lblProfit As Label
    Friend WithEvents btnVote As Button
    Friend WithEvents btnEnd As Button
End Class
